#ifndef EVAL_H
#define EVAL_H

#include "display.h"
#include "put.h"

void eval(char line[]){
        char keyword[1000];
        int length=0,i=0,j=0;
        char main_content[1000];
        if(strlen(line)==0){
                return;
        }
        while(line[i]==' '){
                i++;
        }
        while(line[i]!=' '){
                keyword[j++]=line[i++];
        }
        keyword[j]='\0';
        j=0;
        i++;
        while(line[i]!='\0'){
                main_content[j++]=line[i++];
        }
        main_content[j]='\0';
        if(strcmp(keyword,"display")==0){
                display(main_content);
        }else if(keyword[0]=='$'){
                //comment 'symbol' , its for both single, multi line .
        }else if(strcmp(keyword,"put")==0){
                put(main_content);
        }
        else{
                printf("::Error::'%s' Keyword not found !\n",keyword);
        }
}

#endif
