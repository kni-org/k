#ifndef EVAL_H
#define EVAL_H

#include "display.h"
#include "put.h"
#include "set.h"
#include "change.h"
#include "let.h"
#include "get.h"
#include "sys.h"

void eval(char line[]);

#include "loop.h"
#include "fun.h"
#include "pause.h"

void eval(char line[]){
	char keyword[1000];
	int length=0,i=0,j=0;
	char main_content[1000];
	if(strlen(line)==0){
		return;
	}
	while(line[i]==' '){
		i++;
	}
	while(line[i]!=' ' && line[i]!='\0'){
		keyword[j++]=line[i++];
	}
	keyword[j]='\0';
	j=0;
	i++;
	while(line[i]!='\0'){
		main_content[j++]=line[i++];
	}
	main_content[j]='\0';
	if(strcmp(keyword,"display")==0){
		display(main_content);
	}else if(keyword[0]=='$'){
		//comment 'symbol' , its for both single, multi line .
	}else if(strcmp(keyword,"put")==0){
		put(main_content);
	}else if(strcmp(keyword,"set")==0){
		set(main_content);
	}else if(strcmp(keyword,"change")==0){
		change(main_content);
	}else if(strcmp(keyword,"get")==0){
		get(main_content);
	}else if(strcmp(keyword,"let")==0){
		let(main_content);
	}else if(strcmp(keyword,"...")==0){
		sys(main_content);
	}else if(strcmp(keyword,"loop")==0){
		loop(main_content);
	}else if(strcmp(keyword,".")==0){
		add_loop(main_content);
	}else if(strcmp(keyword,"/loop")==0){
		eval_loop();
	}else if(strcmp(keyword,"fun")==0){
		fun(main_content);
	}else if(strcmp(keyword,"-")==0){
		add_fun(main_content);
	}else if(strcmp(keyword,"/fun")==0){
		end_fun();
	}else if(find_fun(keyword)){
		call_fun(keyword);
	}else if(strcmp(keyword,"pause")==0){
		pause_program(main_content);
	}
	else{
		printf("::Error::'%s' Keyword not found !\n",keyword);
	}
}

#endif
