#ifndef CHANGE_H
#define CHANGE_H

void change(char text[]){
	char var1[1000]="",var2[1000]="";
	int i=0,j=0;
	while(text[i]==' ' && text[i]!='\0'){
		i++;
	}
	while(text[i]!=' ' && text[i]!='\0'){
		var1[j++]=text[i++];
	}
	var1[j]='\0';
	j=0;
	while(text[i]==' ' && text[i]!='\0'){
		i++;
	}
	struct variable *temp = start;
	while(temp!=NULL && strcmp(temp->name,var1)!=0){
                        temp=temp->next;
                }
	if(temp==NULL){
		printf("::Error::variable %s not found !\n",var1);
		return;
	}
	if(text[i]=='"'){
		i++;
		j=0;
		while(text[i]!='"'){
			var2[j++]=text[i++];
		}
		var2[j]='\0';
		strcpy(temp->value,var2);
		return;
	}
	while(text[i]!='\0'){
		var2[j++]=text[i++];
	}
	var2[j]='\0';
	int flage=0;
	struct variable *t = start;
	while(t!=NULL){
		if(strcmp(var2,t->name)==0){
			strcpy(temp->value,t->value);
			flage=1;
			break;
		}
		t=t->next;
	}
	if(flage==0){
		printf("::Error::variable %s not found !\n",var2);
	}
}

#endif
