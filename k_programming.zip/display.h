#ifndef DISPLAY_H
#define DISPLAY_H

#include "put.h"

void display_error(){
	printf("::Error::display syntax !\n");
}

void text_display(char text[]){
	char content[1000];
	int i=0,j=1;
	while(text[j]!='\0' && text[j]!='"'){
		content[i++]=text[j++];
	}
	
	content[i]='\0';
	printf("%s\n",content);
}

void var_display(char text[]){
	char var[1000];
	int i=0,j=0;
	while(text[i]==' '){
		i++;
	}
	while(text[i]!=' ' && text[i]!='\0'){
		var[j++]=text[i++];
	}
	var[j]='\0';
	int flage=0;
	struct variable *temp=start;
	while(temp!=NULL){
		if(strcmp(temp->name,var)==0){
			printf("%s\n",temp->value);
			flage=1;
			break;
		}
		temp=temp->next;
	}
	if(flage==0){
		printf("::Error::Variable %s not found !\n",var);
	}
}

void display_eval(char text[]){
	if(text[0]=='"'){
		text_display(text);
	}else{
		var_display(text);
	}
}

void display(char line[]){
	int i=0,j=0,flage=0;
	char main_content[1000];
	while(line[i]!='>' && line[i]!='\0'){
		if(line[i]==' '){
			i++;
		}else{
			display_error();
			flage=1;
			break;
		}
	}
	if(line[i]=='\0' || flage==1){
		return;
	}
	if(line[i]!='>'){
		printf("::Error::Excepecting '>'\n");
	}else{
		i++;
		while(line[i]==' ' && line[i]!='\0'){
			i++;
		}
		while(line[i]!='\0'){
			main_content[j++]=line[i++];
		}
		display_eval(main_content);
	}
}

#endif
