#ifndef SYS_H
#define SYS_H

void sys(char text[1000]){
	char cmd[1000];
	int i=0,j=0;
	while(text[i]==' '){
		i++;
	}
	while(text[i]!='\0'){
		cmd[j++]=text[i++];
	}
	cmd[j]='\0';
#ifdef _WIN32
	system(cmd);
#else
	system(cmd);
#endif
}

#endif
