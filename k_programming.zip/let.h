#ifndef LET_H
#define LET_H

void let(char text[]){
	int i=0;
	while(text[i]==' '){
		i++;
	}
	char var[1000];
	int j=0;
	while(text[i]!='\0'){
		var[j++]=text[i++];
	}
	if(strlen(var)==0){
		printf("::Error::let syntax error !");
	}else{
		var[j]='\0';
		struct variable *v = (struct variable*)malloc(sizeof(struct variable));
		strcpy(v->name,var);
		strcpy(v->value,"No Data !");
		v->next=NULL;
		if(start==NULL){
			start=end=v;
		}else{
			end->next=v;
			end=v;
		}
	}
}

#endif
