#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "eval.h"


void f_error(){
    printf("::Error::File Not Found !\n");
}

void tokens(char code[]){
    int i=0, l=0, j=0;
    char lines[1000][1000];

    while(code[i] != '\0'){
        j=0;
        while(code[i] != '\n' && code[i] != '\0'){
            lines[l][j++] = code[i++];
        }
        lines[l][j] = '\0';
        l++;

        if(code[i] == '\n') i++;
    }

    for(int j=0; j<l; j++){
        eval(lines[j]);
    }
}

int main(int cl, char *cmd[]){
    if(cl < 2){
        f_error();
        return 0;
    }

    FILE *f = fopen(cmd[1], "r");

    if(f == NULL){
        f_error();
        return 0;
    }

    int it = 0,ch;
    char code[1000];

    while((ch = fgetc(f)) != EOF){
        code[it++] = ch;
    }
    code[it] = '\0';

    fclose(f);

    tokens(code);

    return 0;
}

