#ifndef GET_H
#define GET_H

void get(char text[1000]){
	struct variable *temp;
	char name[1000];
	int i=0,j=0;
	while(text[i]==' '){
		i++;
	}
	while(text[i]!='\0'){
		name[j++]=text[i++];
	}
	name[j]='\0';
	int flage=0;
	temp=start;
	while(temp!=NULL){
		if(strcmp(temp->name,name)==0){
			flage=1;
			break;
		}
		temp=temp->next;
	}
	if(flage==0){
		printf("::Error::variable %s not found !\n",name);
		return;
	}
	char value[1000];
	fgets(value,1000,stdin);
	value[strcspn(value,"\n")]='\0';
	strcpy(temp->value,value);
}

#endif
