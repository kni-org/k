#ifndef SET_H
#define SET_H

void set(char text[]){
	char var1[1000]="",var2[1000]="";
	int i=0,j=0;
	while(text[i]==' ' && text[i]!='\0'){
		i++;
	}
	while(text[i]!=' ' && text[i]!='\0'){
		var1[j++]=text[i++];
	}
	var1[j]='\0';
	j=0;
	while(text[i]==' ' && text[i]!='\0'){
		i++;
	}
	while(text[i]!='\0'){
		var2[j++]=text[i++];
	}
	var2[j]='\0';
	struct variable *temp = start;
	int flage=0;
	while(temp!=NULL){
		if(strcmp(var2,temp->name)==0){
			struct variable *var = (struct variable *)malloc(sizeof(struct variable)) ;
			strcpy(var->name,var1);
			strcpy(var->value,temp->value);
			var->next=NULL;
			end->next=var;
			end=var;
			flage=1;
			break;
		}
	}
	if(flage==0){
		printf("::Error::variable %s not found !\n",var2);
	}
}

#endif
