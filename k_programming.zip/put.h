#ifndef PUT_H
#define PUT_H

struct variable{
        char name[1000];
        char value[1000];
        struct variable *next;
};

struct variable *start=NULL,*end=NULL;

void put(char data[]){
        struct variable *var=(struct variable *)malloc(sizeof(struct variable));
        int i=0,j=0;
        while(data[i]==' '){
                i++;
        }
        while(data[i]!=' '){
                var->name[j++]=data[i++];
        }
        var->name[j]='\0';
        j=0;
        while(data[i]==' '){
                i++;
        }
        while(data[i]!='\0'){
                var->value[j++]=data[i++];
        }
        var->value[j]='\0';
        if(start==NULL){
                start=end=var;
        }else{
                end->next=var;
                end=var;
        }
}

#endif
