#ifndef IMPORT_H
#define IMPORT_H

void impt(char code[1000]){
	int i=0,j=0;
        char file[1000];
        while(code[i]==' '){
                i++;
        }
        int flage=0;
        while(code[i]!='\0'){
                flage=1;
                file[j++]=code[i++];
        }
        if(flage==0){
                printf("::Error::file not found !\n");
        }else{
		file[j++]='.';
		file[j++]='k';
		file[j]='\0';
                FILE *f = fopen(file, "r");
                if(f == NULL){
                        printf("::Error::file not found ,extension should be '.k' !\n");
                        return;
                }
                int it = 0,ch;
                char con[1000];
                while((ch = fgetc(f)) != EOF){
                        con[it++] = ch;
                }
                con[it] = '\0';
                fclose(f);
                tokens(con);
        }
}

#endif
