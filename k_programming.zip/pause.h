#ifndef PAUSE_H
#define PAUSE_H


#ifdef _WIN32
#include<windows.h>
#else
#include<unistd.h>
#endif

void pause_program(char text[]){
	char num[1000];
	int i=0,j=0;
	while(text[i]==' ' && text[i]!='\0'){
		i++;
	}
	while(text[i]!='\0'){
		num[j++]=text[i++];
	}
	num[j]='\0';
	char *p;
	long n=strtol(num,&p,10);
	if(*p=='\0'){
#ifdef _WIN32
		sleep(n*1000);
#else
		sleep(n);
#endif
	}else{
		printf("::Error::pause syntax error !\n");
	}
}

#endif
