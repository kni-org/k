#ifndef PAUSE_H
#define PAUSE_H


#include<unistd.h>

void pause_program(char text[]){
	char num[1000];
	int i=0,j=0;
	while(text[i]==' ' && text[i]!='\0'){
		i++;
	}
	while(text[i]!='\0'){
		num[j++]=text[i++];
	}
	num[j]='\0';
	char *p;
	long n=strtol(num,&p,10);
	if(*p=='\0'){
		sleep(n);
	}else{
		printf("::Error::pause syntax error !\n");
	}
}

#endif
