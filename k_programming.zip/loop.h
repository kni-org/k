#ifndef LOOP_H
#define LOOP_H


struct loop{
    char line[1000];
    struct loop *next;
};

struct LoopContext{
    int it;
    struct loop *start_loop;
    struct loop *end_loop;
};

struct LoopContext stack[100];
int top = -1;

void loop(char text[100]){
    char number[100];
    int i=0,j=0;

    while(text[i]==' ') i++;
    while(text[i]!='\0') number[j++]=text[i++];
    number[j]='\0';

    char *p;
    long n = strtol(number,&p,10);

    top++;
    stack[top].start_loop = NULL;
    stack[top].end_loop = NULL;

    if(strcmp(number,"inf")==0){
        stack[top].it = -1;
    } else {
        if(*p=='\0'){
            stack[top].it = n;
        } else {
            printf("::Error::invalid number!\n");
            top--;
        }
    }
}

void add_loop(char text[100]){
    if(top < 0) return;

    struct loop *c = (struct loop*)malloc(sizeof(struct loop));
    strcpy(c->line,text);
    c->next = NULL;

    if(stack[top].start_loop == NULL){
        stack[top].start_loop = stack[top].end_loop = c;
    } else {
        stack[top].end_loop->next = c;
        stack[top].end_loop = c;
    }
}

void eval_loop(){
    if(top < 0) return;

    int it = stack[top].it;
    struct loop *start_loop = stack[top].start_loop;

    if(it == -1){
        while(1){
            struct loop *temp = start_loop;
            while(temp){
                eval(temp->line);
                temp = temp->next;
            }
        }
    } else {
        for(int i = 0; i < it; i++){
            struct loop *temp = start_loop;
            while(temp){
                eval(temp->line);
                temp = temp->next;
            }
        }
    }

    struct loop *temp = start_loop;
    while(temp){
        struct loop *next = temp->next;
        free(temp);
        temp = next;
    }

    top--;
}

#endif
