#ifndef K_TERMINAL_H
#define K_TERMINAL_H

void help(){
    printf("\n");
    printf("+============================================================+\n");
    printf("|                    K LANGUAGE TERMINAL                     |\n");
    printf("+============================================================+\n\n");

    printf("Developer : Niranjan Kumar K\n");
    printf("Purpose   : Custom scripting and learning environment\n\n");

    printf("+---------------------- CORE COMMANDS -----------------------+\n");
    printf("display > \"text\"       : print output\n");
    printf("put a 10               : create variable\n");
    printf("set a 20               : update variable\n");
    printf("change a b             : copy value\n");
    printf("get a                  : fetch value\n");
    printf("let a                  : creating variable\n\n");

    printf("+---------------------- FLOW CONTROL ------------------------+\n");
    printf("loop n                 : repeat n times\n");
    printf(". <statement>          : add line to loop\n");
    printf("/loop                  : execute loop\n\n");

    printf("+---------------------- FUNCTIONS ---------------------------+\n");
    printf("fun name               : define function\n");
    printf("- <statement>          : add line to function\n");
    printf("/fun                   : end function\n");
    printf("name                   : call function\n\n");

    printf("+---------------------- SYSTEM ------------------------------+\n");
    printf("... command            : execute system command\n");
    printf("pause n                : delay execution (seconds)\n\n");

    printf("+---------------------- SPECIAL -----------------------------+\n");
    printf("$                     : comment line\n");
    printf("help                  : show this help\n");
    printf("_exit                 : exit terminal\n");
    printf("--version             : version of k language\n\n");

    printf("+---------------------- EXAMPLES ----------------------------+\n");
    printf("loop 3\n");
    printf(". display > \"hello\"\n");
    printf("/loop\n\n");

    printf("fun greet\n");
    printf("- display > \"hi\"\n");
    printf("/fun\n");
    printf("greet\n\n");

    printf("+---------------------- FEATURES ----------------------------+\n");
    printf("-> Variables are globally accessible\n");
    printf("-> Supports loops and nested execution\n");
    printf("-> Supports recursive functions\n");
    printf("-> Simple and fast interpreter design\n");
    printf("-> Direct system command execution\n\n");

    printf("+---------------------- FUTURE ------------------------------+\n");
    printf("-> Condition system (if/else)\n");
    printf("-> Expression evaluation\n");
    printf("-> File handling\n");
    printf("-> Advanced scripting engine\n\n");

    printf("+============================================================+\n\n");
}


void terminal(){
	char line[1000];
	printf("+------------------------------------------------+\n|Developer : Niranjan Kumar K                    |\n+------------------------------------------------+\n|Email     : hackerenvironment1514@gmail.com     |\n+------------------------------------------------+\n|Engine    : None                                |\n+------------------------------------------------+\n|Note      : system commands  allowed with ...   |\n+------------------------------------------------+\n\nEnjoy Learning and Practicing   !\n\nExit through _exit command      !\n\n");
	printf("::k::$");
	while(1){
		fgets(line,1000,stdin);
		line[strcspn(line,"\n")]='\0';
		                char key[1000];
                int i=0,j=0;
                while(line[i]==' ' && line[i]!='\0'){
                        i++;
                }
                while(line[i]!=' ' && line[i]!='\0'){
                        key[j++]=line[i++];
                }
                key[j]='\0';
		if(strcmp(key,"help")==0){
			help();
			continue;
		}
		if(strcmp(key,"--version")==0){
			printf("::version::1.0\n");
			continue;
		}
		if(strcmp(line,"_exit")==0){
			break;
		}else{
			eval(line);
		}
		if(strcmp(key,"fun")==0 || strcmp(key,"-")==0 || strcmp(key,"loop")==0 || strcmp(key,".")==0){
			//continues of code ....
		}else{
			printf("::k::$");
		}
	}
	printf("\nSuccessfully Exited from K terminal ....     !\n\nNiranjan Special Thanked, for using Terminal !\n");
}

#endif
