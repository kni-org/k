#ifndef FUN_H
#define FUN_H



struct fun_line{
    char line[1000];
    struct fun_line *next;
};

struct function{
    char name[100];
    struct fun_line *start;
    struct fun_line *end;
    struct function *next;
};

struct function *fun_list = NULL;

struct {
    char name[100];
    struct fun_line *start;
    struct fun_line *end;
} fun_stack[100];

int fun_top = -1;

void fun(char text[100]){
    char name[100];
    int i=0,j=0;

    while(text[i]==' ') i++;
    while(text[i]!='\0') name[j++]=text[i++];
    name[j]='\0';

    fun_top++;
    strcpy(fun_stack[fun_top].name, name);
    fun_stack[fun_top].start = NULL;
    fun_stack[fun_top].end = NULL;
}

void add_fun(char text[100]){
    if(fun_top < 0) return;

    struct fun_line *c = (struct fun_line*)malloc(sizeof(struct fun_line));
    strcpy(c->line, text);
    c->next = NULL;

    if(fun_stack[fun_top].start == NULL){
        fun_stack[fun_top].start = fun_stack[fun_top].end = c;
    } else {
        fun_stack[fun_top].end->next = c;
        fun_stack[fun_top].end = c;
    }
}

void end_fun(){
    if(fun_top < 0) return;

    struct function *f = (struct function*)malloc(sizeof(struct function));
    strcpy(f->name, fun_stack[fun_top].name);
    f->start = fun_stack[fun_top].start;
    f->end = fun_stack[fun_top].end;
    f->next = fun_list;
    fun_list = f;

    fun_top--;
}

struct function* find_fun(char *name){
    struct function *temp = fun_list;
    while(temp){
        if(strcmp(temp->name, name) == 0) return temp;
        temp = temp->next;
    }
    return NULL;
}

void call_fun(char name[100]){
    struct function *f = find_fun(name);
    if(!f){
        printf("::Error::function '%s' not found!\n", name);
        return;
    }

    struct fun_line *temp = f->start;
    while(temp){
        eval(temp->line);
        temp = temp->next;
    }
}

#endif
